public interface LoanConstants {
	int shortTerm = 1;
	int mediumTerm = 3;
	int longTerm = 5;
	String companyName = "Care Construction Loan";
	int maxLoanAmount = 500000;
}
